package com.rombosaur.game;

import org.flixel.FlxGame;

public class MainGame extends FlxGame {
	public MainGame() {
		super(400, 240, PlayState.class, 2);
	}
}
