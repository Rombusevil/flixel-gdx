package com.rombosaur.game;

import org.flixel.FlxSprite;
import org.flixel.FlxState;

/**
 * Created by rombus on 18/03/17.
 */
public class PlayState extends FlxState {
    @Override
    public void create() {
        add(new FlxSprite(10, 10));
    }
}
