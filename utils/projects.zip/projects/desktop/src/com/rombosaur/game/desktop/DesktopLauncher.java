package com.rombosaur.game.desktop;

import com.rombosaur.game.MainGame;
import org.flixel.FlxDesktopApplication;

public class DesktopLauncher {
	public static void main (String[] arg) {
		new FlxDesktopApplication(new MainGame(), 800, 480);
	}
}
