package com.rombosaur.game;

import org.flixel.FlxAndroidApplication;

public class AndroidLauncher extends FlxAndroidApplication {

	public AndroidLauncher() {
		super(new MainGame());
	}
}
